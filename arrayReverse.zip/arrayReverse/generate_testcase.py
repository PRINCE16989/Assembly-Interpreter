import math
import random
import os

# Create output and input directories if they don't exist
os.makedirs("output", exist_ok=True)
os.makedirs("input", exist_ok=True)

for i in range(1, 51):
    x = random.randint(1, 20)
    c = [random.randint(1, 100) for _ in range(x)]
    # Output file: a{j} {j * 4} {c[j]}
    content_out = [f"a{j} {j * 4} {c[j]}\n" for j in range(x)]
    content_out.append(f"n {x*4} {len(c)}")
    fname_out = f"output/output{i:02d}.txt"
    with open(fname_out, "w") as f_out:
        f_out.writelines(content_out)

    # Input file: a{j} {j * 4} {c[x-j-1]}
    content_in = [f"a{j} {j * 4} {c[x-j-1]}\n" for j in range(x)]
    content_in.append(f"n {x*4} {len(c)}")
    fname_in = f"input/input{i:02d}.txt"
    with open(fname_in, "w") as f_in:
        f_in.writelines(content_in)

print("All 50 testcases are generated.")
import math
import random
import zipfile
import os

# Create 50 output in separate files
os.makedirs("output", exist_ok=True)
os.makedirs("input", exist_ok=True)
for i in range(1, 51):
    x = random.randint(1, 100)
    y = random.randint(1, 100)
    gcd = math.gcd(x, y)
    content = f"a 0 {x}\nb 4 {y}\ngcd 8 {gcd}\n"
    fname = f"output/output{i:02d}.txt"
    with open(fname, "w") as f:
        f.write(content)

    content = f"a 0 {x}\nb 4 {y}\ngcd 8 0\n"
    fname = f"input/input{i:02d}.txt"
    with open(fname, "w") as f:
        f.write(content)

print("All 50 testcases are generated.")
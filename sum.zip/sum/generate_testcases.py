import math
import os
import random

os.makedirs("input", exist_ok=True)
os.makedirs("output", exist_ok=True)

for x in range(1, 100) :
    n = random.randint(1, 100)
    content = f"n 0 {n}\nresult 4 0\n"
    with open(f"input/input{x:02d}.txt", "w") as f:
        f.write(content)
    content = f"n 0 {n}\nresult 4 {n*(n + 1) // 2}\n"
    with open(f"output/output{x:02d}.txt", "w") as f:
        f.write(content)
    
print("Test cases generated successfully.")
# This script generates test cases for a problem that calculates the sum of the first n natural numbers.